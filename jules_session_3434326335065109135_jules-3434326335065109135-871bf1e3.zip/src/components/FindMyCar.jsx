import React, { useState } from 'react';
import { useParking } from '../context/ParkingContext';
import { Search, MapPin, Navigation, Compass, AlertCircle, Sparkles, Building, Car, User, ArrowRight } from 'lucide-react';

export default function FindMyCar() {
  const { spots, setSelectedSpot, setActiveLevel } = useParking();
  const [query, setQuery] = useState('');
  const [result, setResult] = useState(null);
  const [hasSearched, setHasSearched] = useState(false);

  const handleSearch = (e) => {
    e.preventDefault();
    if (!query.trim()) return;

    setHasSearched(true);
    const q = query.trim().toLowerCase();

    const matchedSpot = spots.find(s =>
      s.vehicle && (
        s.vehicle.plate.toLowerCase().includes(q) ||
        s.vehicle.unit.toLowerCase().includes(q) ||
        s.vehicle.owner.toLowerCase().includes(q) ||
        s.id.toLowerCase() === q
      )
    );

    if (matchedSpot) {
      setResult(matchedSpot);
    } else {
      setResult(null);
    }
  };

  const handleLocateOnMap = (spot) => {
    setActiveLevel(spot.level);
    setSelectedSpot(spot);
    // Smooth scroll to parking grid
    window.scrollTo({ top: 350, behavior: 'smooth' });
  };

  return (
    <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-6 shadow-xl backdrop-blur-md">
      <div className="flex items-center justify-between pb-4 border-b border-slate-800 mb-6">
        <div>
          <h2 className="text-2xl font-bold text-white flex items-center gap-2">
            <Search className="w-6 h-6 text-indigo-400" />
            <span>'Find My Car' & Wayfinding Navigation</span>
          </h2>
          <p className="text-slate-400 text-xs mt-1">Locate parked vehicles by license plate or apartment unit number with step-by-step indoor directions</p>
        </div>

        <span className="text-xs px-3 py-1 bg-indigo-500/20 text-indigo-300 border border-indigo-500/30 rounded-full font-medium flex items-center gap-1.5">
          <Compass className="w-3.5 h-3.5 text-indigo-400" /> GPS Indoor Positioning
        </span>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-12 gap-6">
        {/* Search Bar & Instructions */}
        <div className="md:col-span-5 space-y-4">
          <form onSubmit={handleSearch} className="space-y-3">
            <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider">
              Search Vehicle or Apartment
            </label>
            <div className="relative">
              <input
                type="text"
                placeholder="Plate e.g. EV-882-99 or Unit e.g. A-701"
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                className="w-full bg-slate-950 border border-slate-700 rounded-xl py-3 pl-4 pr-10 text-white placeholder-slate-500 focus:outline-none focus:border-indigo-500 text-sm shadow-inner"
              />
              <button
                type="submit"
                className="absolute right-2 top-2 p-1.5 bg-indigo-600 hover:bg-indigo-500 text-white rounded-lg transition shadow"
              >
                <Search className="w-4 h-4" />
              </button>
            </div>

            <div className="flex flex-wrap gap-1.5 text-[11px] text-slate-400 pt-1">
              <span className="text-slate-500">Try searching:</span>
              <button type="button" onClick={() => { setQuery('A-701'); }} className="text-indigo-400 hover:underline">A-701</button>,
              <button type="button" onClick={() => { setQuery('VIP-777'); }} className="text-indigo-400 hover:underline">VIP-777</button>,
              <button type="button" onClick={() => { setQuery('GUEST-901'); }} className="text-indigo-400 hover:underline">GUEST-901</button>
            </div>
          </form>

          <div className="bg-slate-950 p-4 rounded-xl border border-slate-800/80 space-y-2 text-xs text-slate-400">
            <h4 className="font-semibold text-slate-200 flex items-center gap-1.5">
              <Building className="w-4 h-4 text-indigo-400" /> Tower Wayfinding System
            </h4>
            <p>Integrated indoor sensors pinpoint slot locations relative to Tower A, B, and C elevator lobby exits.</p>
          </div>
        </div>

        {/* Search Result & Route Display */}
        <div className="md:col-span-7">
          {result ? (
            <div className="bg-slate-950 p-5 rounded-2xl border border-indigo-500/40 space-y-4 animate-in fade-in duration-200">
              <div className="flex items-center justify-between pb-3 border-b border-slate-800">
                <div className="flex items-center gap-3">
                  <div className="p-3 bg-indigo-500/20 text-indigo-400 rounded-xl border border-indigo-500/30">
                    <MapPin className="w-6 h-6" />
                  </div>
                  <div>
                    <h3 className="text-lg font-bold text-white flex items-center gap-2">
                      Slot Location: <span className="text-indigo-400 font-mono">{result.id}</span>
                    </h3>
                    <p className="text-xs text-slate-400">Level {result.level} • {result.type} Parking Zone</p>
                  </div>
                </div>

                <button
                  onClick={() => handleLocateOnMap(result)}
                  className="px-3.5 py-2 bg-indigo-600 hover:bg-indigo-500 text-white rounded-xl text-xs font-semibold shadow-lg shadow-indigo-600/30 transition flex items-center gap-1.5"
                >
                  <span>Highlight on Grid</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </button>
              </div>

              {/* Vehicle & Owner Info */}
              {result.vehicle && (
                <div className="grid grid-cols-2 gap-3 text-xs">
                  <div className="bg-slate-900 p-3 rounded-xl border border-slate-800">
                    <span className="text-slate-500 block text-[10px] uppercase tracking-wider mb-1">License Plate</span>
                    <span className="font-mono font-bold text-amber-300 text-sm bg-amber-950/40 px-2 py-0.5 rounded border border-amber-500/20 inline-block">
                      {result.vehicle.plate}
                    </span>
                  </div>
                  <div className="bg-slate-900 p-3 rounded-xl border border-slate-800">
                    <span className="text-slate-500 block text-[10px] uppercase tracking-wider mb-1">Apartment Unit</span>
                    <span className="font-bold text-white text-sm">{result.vehicle.unit}</span>
                  </div>
                  <div className="bg-slate-900 p-3 rounded-xl border border-slate-800 col-span-2 flex items-center justify-between">
                    <span className="text-slate-400 flex items-center gap-1.5"><User className="w-3.5 h-3.5 text-indigo-400" /> Owner / Registered Resident:</span>
                    <span className="font-medium text-slate-200">{result.vehicle.owner}</span>
                  </div>
                </div>
              )}

              {/* Step-by-Step Walking Directions */}
              <div className="bg-slate-900/90 p-4 rounded-xl border border-slate-800 space-y-2">
                <h4 className="text-xs font-bold text-slate-200 uppercase tracking-wider flex items-center gap-1.5">
                  <Navigation className="w-4 h-4 text-emerald-400" /> Step-by-Step Directions from Resident Elevator
                </h4>
                <ol className="text-xs text-slate-300 space-y-1.5 list-decimal list-inside pl-1">
                  <li>Take Elevator Bank A / B to <strong className="text-indigo-300">Level {result.level}</strong>.</li>
                  <li>Turn right upon exiting lobby doors toward Pillar <strong className="text-amber-300">#{result.id.slice(-2)}</strong>.</li>
                  <li>Vehicle is parked in slot <strong className="text-emerald-300">{result.id}</strong> on row {result.id.startsWith('B1') ? 'North EV Aisle' : 'Resident Sector'}.</li>
                </ol>
              </div>
            </div>
          ) : hasSearched ? (
            <div className="bg-slate-950 p-8 rounded-2xl border border-slate-800 text-center text-slate-400 space-y-2">
              <AlertCircle className="w-10 h-10 text-amber-400 mx-auto opacity-80" />
              <h4 className="text-base font-bold text-slate-200">No Parked Vehicle Found</h4>
              <p className="text-xs text-slate-500 max-w-sm mx-auto">
                No active parked car matched query "{query}". Please check the plate or unit number.
              </p>
            </div>
          ) : (
            <div className="bg-slate-950 p-8 rounded-2xl border border-slate-800/80 text-center text-slate-500 space-y-2">
              <Compass className="w-10 h-10 text-indigo-500/50 mx-auto" />
              <p className="text-xs">Enter a license plate or apartment unit to search and view directions.</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
