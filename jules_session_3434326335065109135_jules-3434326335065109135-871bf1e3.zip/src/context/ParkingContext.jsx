import React, { createContext, useContext, useState, useEffect } from 'react';
import { INITIAL_SPOTS, INITIAL_LOGS, REGISTERED_RESIDENTS, PARKING_LEVELS, TOWERS } from '../data/parkingData';

const ParkingContext = createContext();

export function ParkingProvider({ children }) {
  const [spots, setSpots] = useState(INITIAL_SPOTS);
  const [logs, setLogs] = useState(INITIAL_LOGS);
  const [residents, setResidents] = useState(REGISTERED_RESIDENTS);
  const [activeLevel, setActiveLevel] = useState('B1');
  const [selectedSpot, setSelectedSpot] = useState(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [searchResult, setSearchResult] = useState(null);
  const [isSimulating, setIsSimulating] = useState(false);
  const [alerts, setAlerts] = useState([
    { id: 'ALT-1', type: 'info', message: 'Level B1 EV Charging Station 01 operating at optimal 22kW.', time: '10 min ago' },
    { id: 'ALT-2', type: 'warning', message: 'GUEST-312 pass nearing expiration in 45 minutes.', time: '25 min ago' }
  ]);

  // Handle vehicle parking / spot reservation
  const assignSpot = (spotId, vehicleInfo) => {
    setSpots(prevSpots =>
      prevSpots.map(spot => {
        if (spot.id === spotId) {
          return {
            ...spot,
            status: 'OCCUPIED',
            vehicle: vehicleInfo,
            evCharging: spot.type === 'EV' ? { isCharging: true, batteryPercent: 20, kwPower: 11, startTime: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) } : spot.evCharging
          };
        }
        return spot;
      })
    );

    const newLog = {
      id: `LOG-${Date.now().toString().slice(-4)}`,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      plate: vehicleInfo.plate,
      action: 'ENTRY',
      gate: 'Main Gate',
      result: 'ASSIGNED MANUAL',
      unit: vehicleInfo.unit || 'N/A',
      spotAssigned: spotId
    };
    setLogs(prev => [newLog, ...prev]);
  };

  // Handle freeing up a spot
  const releaseSpot = (spotId) => {
    const spotToRelease = spots.find(s => s.id === spotId);
    setSpots(prevSpots =>
      prevSpots.map(spot => {
        if (spot.id === spotId) {
          return {
            ...spot,
            status: 'AVAILABLE',
            vehicle: null,
            evCharging: spot.type === 'EV' ? { isCharging: false, batteryPercent: 0, kwPower: 0, startTime: null } : undefined
          };
        }
        return spot;
      })
    );

    if (spotToRelease && spotToRelease.vehicle) {
      const newLog = {
        id: `LOG-${Date.now().toString().slice(-4)}`,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        plate: spotToRelease.vehicle.plate,
        action: 'EXIT',
        gate: 'Main Exit Barrier',
        result: 'DEPARTED',
        unit: spotToRelease.vehicle.unit || 'N/A',
        spotAssigned: spotId
      };
      setLogs(prev => [newLog, ...prev]);
    }
  };

  // Toggle EV charging status
  const toggleEVCharging = (spotId) => {
    setSpots(prevSpots =>
      prevSpots.map(spot => {
        if (spot.id === spotId && spot.evCharging) {
          const isNowCharging = !spot.evCharging.isCharging;
          return {
            ...spot,
            evCharging: {
              ...spot.evCharging,
              isCharging: isNowCharging,
              kwPower: isNowCharging ? 22 : 0
            }
          };
        }
        return spot;
      })
    );
  };

  // ANPR Gate entry processing
  const processANPREntry = (plateInput, isVisitorPass = false, guestUnit = '') => {
    const plate = plateInput.trim().toUpperCase();
    if (!plate) return { success: false, message: 'Please enter a valid license plate number.' };

    // 1. Check if resident
    const resident = residents.find(r => r.primaryPlate.toUpperCase() === plate || (r.secondaryPlate && r.secondaryPlate.toUpperCase() === plate));

    if (resident) {
      const assignedSpotId = resident.primaryPlate.toUpperCase() === plate ? resident.primarySpot : resident.secondarySpot;
      const targetSpot = spots.find(s => s.id === assignedSpotId);

      if (targetSpot && targetSpot.status === 'AVAILABLE') {
        assignSpot(assignedSpotId, {
          plate: plate,
          model: 'Resident Vehicle',
          owner: resident.name,
          unit: resident.unit,
          type: 'Resident'
        });
        return { success: true, message: `Access Granted! Welcome ${resident.name}. Proceed to spot ${assignedSpotId}.`, spot: assignedSpotId };
      } else {
        // Find alternate resident spot
        const altSpot = spots.find(s => s.status === 'AVAILABLE' && (s.type === 'RESIDENT' || s.type === 'EV'));
        if (altSpot) {
          assignSpot(altSpot.id, {
            plate: plate,
            model: 'Resident Vehicle',
            owner: resident.name,
            unit: resident.unit,
            type: 'Resident'
          });
          return { success: true, message: `Access Granted! Reserved spot occupied. Re-assigned to ${altSpot.id}.`, spot: altSpot.id };
        }
      }
    }

    // 2. Check Visitor
    if (isVisitorPass || guestUnit) {
      const visitorSpot = spots.find(s => s.level === 'Ground' && s.status === 'AVAILABLE' && s.type === 'VISITOR');
      if (visitorSpot) {
        assignSpot(visitorSpot.id, {
          plate: plate,
          model: 'Guest Vehicle',
          owner: `Guest of Unit ${guestUnit || 'Host'}`,
          unit: guestUnit || 'Visitor',
          type: 'Visitor',
          passExpires: '6 Hours'
        });
        return { success: true, message: `Visitor Pass Validated! Assigned Ground Spot ${visitorSpot.id}. Barrier Open.`, spot: visitorSpot.id };
      } else {
        return { success: false, message: 'Access Denied: Visitor parking is currently full.' };
      }
    }

    // Unregistered plate rejected
    const newLog = {
      id: `LOG-${Date.now().toString().slice(-4)}`,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      plate: plate,
      action: 'DENIED',
      gate: 'ANPR Main Gate',
      result: 'UNREGISTERED PLATE',
      unit: 'N/A',
      spotAssigned: '-'
    };
    setLogs(prev => [newLog, ...prev]);

    setAlerts(prev => [
      { id: `ALT-${Date.now()}`, type: 'danger', message: `Unauthorized vehicle ${plate} attempted entry at ANPR Main Gate.`, time: 'Just now' },
      ...prev
    ]);

    return { success: false, message: 'Access Denied: Unregistered license plate. Please contact security.' };
  };

  // Issue new visitor pass
  const issueVisitorPass = (guestName, plate, hostUnit) => {
    const newPass = {
      name: guestName,
      unit: hostUnit,
      tower: hostUnit.startsWith('A') ? 'Tower A' : hostUnit.startsWith('B') ? 'Tower B' : 'Tower C',
      primaryPlate: plate.toUpperCase(),
      primarySpot: 'G-FLEX',
      secondaryPlate: null,
      secondarySpot: null
    };
    setResidents(prev => [newPass, ...prev]);
    setAlerts(prev => [{ id: `ALT-${Date.now()}`, type: 'info', message: `New digital guest pass issued for plate ${plate} by unit ${hostUnit}.`, time: 'Just now' }, ...prev]);
  };

  // Search function for "Find My Car"
  const searchVehicleOrUnit = (query) => {
    if (!query) {
      setSearchResult(null);
      return;
    }
    const q = query.trim().toLowerCase();
    const foundSpot = spots.find(s =>
      s.vehicle && (
        s.vehicle.plate.toLowerCase().includes(q) ||
        s.vehicle.unit.toLowerCase().includes(q) ||
        s.vehicle.owner.toLowerCase().includes(q) ||
        s.id.toLowerCase() === q
      )
    );

    if (foundSpot) {
      setSearchResult(foundSpot);
      setActiveLevel(foundSpot.level);
    } else {
      setSearchResult('NOT_FOUND');
    }
  };

  // Live simulation tick (battery increment, occasional entry/exit)
  useEffect(() => {
    if (!isSimulating) return;

    const interval = setInterval(() => {
      setSpots(prev =>
        prev.map(spot => {
          if (spot.evCharging && spot.evCharging.isCharging) {
            const nextPercent = Math.min(100, spot.evCharging.batteryPercent + Math.floor(Math.random() * 3) + 1);
            return {
              ...spot,
              evCharging: {
                ...spot.evCharging,
                batteryPercent: nextPercent,
                isCharging: nextPercent < 100
              }
            };
          }
          return spot;
        })
      );
    }, 3000);

    return () => clearInterval(interval);
  }, [isSimulating]);

  // Overall Statistics Calculations
  const totalCapacity = spots.length;
  const occupiedCount = spots.filter(s => s.status === 'OCCUPIED').length;
  const availableCount = totalCapacity - occupiedCount;
  const activeEvCharges = spots.filter(s => s.evCharging && s.evCharging.isCharging).length;
  const visitorSpotsCount = spots.filter(s => s.type === 'VISITOR').length;
  const occupiedVisitorCount = spots.filter(s => s.type === 'VISITOR' && s.status === 'OCCUPIED').length;

  return (
    <ParkingContext.Provider
      value={{
        spots,
        logs,
        residents,
        towers: TOWERS,
        parkingLevels: PARKING_LEVELS,
        activeLevel,
        setActiveLevel,
        selectedSpot,
        setSelectedSpot,
        searchQuery,
        setSearchQuery,
        searchResult,
        searchVehicleOrUnit,
        assignSpot,
        releaseSpot,
        toggleEVCharging,
        processANPREntry,
        issueVisitorPass,
        isSimulating,
        setIsSimulating,
        alerts,
        stats: {
          totalCapacity,
          occupiedCount,
          availableCount,
          occupancyPercentage: Math.round((occupiedCount / totalCapacity) * 100),
          activeEvCharges,
          visitorSpotsCount,
          occupiedVisitorCount
        }
      }}
    >
      {children}
    </ParkingContext.Provider>
  );
}

export const useParking = () => useContext(ParkingContext);
