import React, { useState } from 'react';
import { ParkingProvider, useParking } from './context/ParkingContext';
import ParkingFloorPlan from './components/ParkingFloorPlan';
import GateBarrierSimulator from './components/GateBarrierSimulator';
import FindMyCar from './components/FindMyCar';
import EVHubAndVisitorPasses from './components/EVHubAndVisitorPasses';
import {
  Car,
  Building2,
  Zap,
  ShieldAlert,
  Play,
  Pause,
  Layers,
  Search,
  Ticket,
  Users,
  Compass,
  Activity,
  CheckCircle2,
  Bell
} from 'lucide-react';

function DashboardContent() {
  const { stats, alerts, isSimulating, setIsSimulating } = useParking();
  const [activeView, setActiveView] = useState('MAP');

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col">
      {/* Top Navigation Bar */}
      <header className="border-b border-slate-800 bg-slate-900/90 backdrop-blur-md sticky top-0 z-40">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-20 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="p-2.5 bg-indigo-600 rounded-xl shadow-lg shadow-indigo-600/30 text-white">
              <Building2 className="w-6 h-6" />
            </div>
            <div>
              <h1 className="text-xl font-bold text-white tracking-tight flex items-center gap-2">
                Grand Horizon Apartments
                <span className="text-[11px] font-semibold bg-indigo-500/20 text-indigo-300 border border-indigo-500/30 px-2.5 py-0.5 rounded-full">
                  Smart Parking Hub
                </span>
              </h1>
              <p className="text-xs text-slate-400">Multi-Tower Resident & Guest Automated Parking Infrastructure</p>
            </div>
          </div>

          {/* Quick Simulation & Live Controls */}
          <div className="flex items-center gap-3">
            <button
              onClick={() => setIsSimulating(!isSimulating)}
              className={`px-4 py-2 rounded-xl text-xs font-bold transition flex items-center gap-2 border shadow-sm ${
                isSimulating
                  ? 'bg-amber-500/20 text-amber-300 border-amber-500/40 animate-pulse'
                  : 'bg-slate-800 hover:bg-slate-700 text-slate-200 border-slate-700'
              }`}
            >
              {isSimulating ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4 text-emerald-400" />}
              <span>{isSimulating ? 'Pause Traffic Sim' : 'Live Traffic Simulation'}</span>
            </button>
          </div>
        </div>
      </header>

      {/* Main Content Area */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
        {/* Metric Overview Dashboard Cards */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5">
          <div className="bg-slate-900/90 border border-slate-800 p-5 rounded-2xl shadow-xl flex items-center justify-between">
            <div>
              <span className="text-xs font-semibold text-slate-400 uppercase tracking-wider block">Total Occupancy</span>
              <div className="flex items-baseline gap-2 mt-1">
                <span className="text-2xl font-bold text-white font-mono">{stats.occupiedCount} / {stats.totalCapacity}</span>
                <span className="text-xs text-indigo-400 font-semibold">{stats.occupancyPercentage}%</span>
              </div>
              <span className="text-[11px] text-slate-500 mt-1 block">{stats.availableCount} Open Spaces Available</span>
            </div>
            <div className="p-3 bg-indigo-500/10 text-indigo-400 border border-indigo-500/20 rounded-xl">
              <Car className="w-6 h-6" />
            </div>
          </div>

          <div className="bg-slate-900/90 border border-slate-800 p-5 rounded-2xl shadow-xl flex items-center justify-between">
            <div>
              <span className="text-xs font-semibold text-slate-400 uppercase tracking-wider block">EV Chargers Active</span>
              <div className="flex items-baseline gap-2 mt-1">
                <span className="text-2xl font-bold text-cyan-300 font-mono">{stats.activeEvCharges} Sessions</span>
              </div>
              <span className="text-[11px] text-slate-500 mt-1 block">Level B1 & B2 High-Speed Stations</span>
            </div>
            <div className="p-3 bg-cyan-500/10 text-cyan-400 border border-cyan-500/20 rounded-xl">
              <Zap className="w-6 h-6" />
            </div>
          </div>

          <div className="bg-slate-900/90 border border-slate-800 p-5 rounded-2xl shadow-xl flex items-center justify-between">
            <div>
              <span className="text-xs font-semibold text-slate-400 uppercase tracking-wider block">Ground Visitor Bays</span>
              <div className="flex items-baseline gap-2 mt-1">
                <span className="text-2xl font-bold text-amber-300 font-mono">{stats.occupiedVisitorCount} / {stats.visitorSpotsCount}</span>
              </div>
              <span className="text-[11px] text-slate-500 mt-1 block">Guest Passes Issued</span>
            </div>
            <div className="p-3 bg-amber-500/10 text-amber-400 border border-amber-500/20 rounded-xl">
              <Ticket className="w-6 h-6" />
            </div>
          </div>

          <div className="bg-slate-900/90 border border-slate-800 p-5 rounded-2xl shadow-xl flex items-center justify-between">
            <div>
              <span className="text-xs font-semibold text-slate-400 uppercase tracking-wider block">Security Status</span>
              <div className="flex items-baseline gap-2 mt-1">
                <span className="text-2xl font-bold text-emerald-400">ANPR Online</span>
              </div>
              <span className="text-[11px] text-slate-500 mt-1 block">All Barrier Gates Nominal</span>
            </div>
            <div className="p-3 bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 rounded-xl">
              <CheckCircle2 className="w-6 h-6" />
            </div>
          </div>
        </div>

        {/* View Switcher Navigation Tabs */}
        <div className="flex bg-slate-900 p-1.5 rounded-2xl border border-slate-800 gap-2 overflow-x-auto">
          {[
            { id: 'MAP', label: 'Interactive Deck Layout', icon: Layers },
            { id: 'GATE', label: 'ANPR Gate Barrier Simulator', icon: Activity },
            { id: 'FIND', label: "'Find My Car' Navigation", icon: Compass },
            { id: 'EV_DIRECTORY', label: 'EV Network & Resident Passes', icon: Zap },
          ].map((tab) => {
            const Icon = tab.icon;
            const isActive = activeView === tab.id;
            return (
              <button
                key={tab.id}
                onClick={() => setActiveView(tab.id)}
                className={`flex items-center gap-2 px-5 py-3 rounded-xl font-semibold text-xs transition-all duration-200 whitespace-nowrap ${
                  isActive
                    ? 'bg-indigo-600 text-white shadow-lg shadow-indigo-600/30'
                    : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/50'
                }`}
              >
                <Icon className="w-4 h-4" />
                <span>{tab.label}</span>
              </button>
            );
          })}
        </div>

        {/* Dynamic Main View Component */}
        {activeView === 'MAP' && <ParkingFloorPlan />}
        {activeView === 'GATE' && <GateBarrierSimulator />}
        {activeView === 'FIND' && <FindMyCar />}
        {activeView === 'EV_DIRECTORY' && <EVHubAndVisitorPasses />}

        {/* Security Alerts Footer Stream */}
        <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-5 shadow-xl">
          <div className="flex items-center justify-between pb-3 border-b border-slate-800 mb-3">
            <h3 className="text-xs font-bold uppercase tracking-wider text-slate-300 flex items-center gap-2">
              <Bell className="w-4 h-4 text-amber-400" /> System Alerts & Notifications
            </h3>
            <span className="text-[10px] text-slate-500 font-mono">Real-time Feed</span>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            {alerts.slice(0, 2).map((alert) => (
              <div
                key={alert.id}
                className={`p-3 rounded-xl border text-xs flex items-center gap-3 ${
                  alert.type === 'danger'
                    ? 'bg-rose-950/30 border-rose-500/40 text-rose-300'
                    : alert.type === 'warning'
                    ? 'bg-amber-950/30 border-amber-500/40 text-amber-300'
                    : 'bg-indigo-950/30 border-indigo-500/40 text-indigo-300'
                }`}
              >
                <ShieldAlert className="w-5 h-5 flex-shrink-0" />
                <div className="flex-1">
                  <p className="font-medium">{alert.message}</p>
                  <span className="text-[10px] opacity-75">{alert.time}</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      </main>

      {/* Footer */}
      <footer className="border-t border-slate-800 py-6 text-center text-xs text-slate-500">
        Grand Horizon Apartment Complex • Smart Automated Parking Management System
      </footer>
    </div>
  );
}

export default function App() {
  return (
    <ParkingProvider>
      <DashboardContent />
    </ParkingProvider>
  );
}
