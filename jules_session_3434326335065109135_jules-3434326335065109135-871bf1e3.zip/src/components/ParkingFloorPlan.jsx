import React, { useState } from 'react';
import { useParking } from '../context/ParkingContext';
import { Car, Zap, Accessibility, ShieldCheck, User, BatteryCharging, AlertCircle, CheckCircle2, Clock, X, Lock } from 'lucide-react';

export default function ParkingFloorPlan() {
  const { spots, parkingLevels, activeLevel, setActiveLevel, selectedSpot, setSelectedSpot, releaseSpot, toggleEVCharging, assignSpot } = useParking();
  const [filterType, setFilterType] = useState('ALL');
  const [showAssignModal, setShowAssignModal] = useState(false);
  const [manualPlate, setManualPlate] = useState('');
  const [manualUnit, setManualUnit] = useState('');
  const [manualOwner, setManualOwner] = useState('');

  const currentLevelInfo = parkingLevels.find(l => l.id === activeLevel);
  const levelSpots = spots.filter(s => s.level === activeLevel);

  const filteredSpots = levelSpots.filter(spot => {
    if (filterType === 'AVAILABLE') return spot.status === 'AVAILABLE';
    if (filterType === 'OCCUPIED') return spot.status === 'OCCUPIED';
    if (filterType === 'EV') return spot.type === 'EV' || (spot.evCharging && spot.evCharging.isCharging);
    if (filterType === 'VISITOR') return spot.type === 'VISITOR';
    return true;
  });

  const handleManualAssign = (e) => {
    e.preventDefault();
    if (!selectedSpot || !manualPlate) return;
    assignSpot(selectedSpot.id, {
      plate: manualPlate.toUpperCase(),
      model: 'Custom Vehicle',
      owner: manualOwner || 'Resident Guest',
      unit: manualUnit || 'A-101',
      type: selectedSpot.type === 'VISITOR' ? 'Visitor' : 'Resident'
    });
    setShowAssignModal(false);
    setManualPlate('');
    setManualUnit('');
    setManualOwner('');
    setSelectedSpot(null);
  };

  return (
    <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-6 shadow-xl backdrop-blur-md">
      {/* Level Tabs Header */}
      <div className="flex flex-wrap items-center justify-between gap-4 pb-6 border-b border-slate-800">
        <div>
          <h2 className="text-2xl font-bold text-white flex items-center gap-2">
            <span>Building Parking Deck Layout</span>
            <span className="text-xs px-2.5 py-1 bg-indigo-500/20 text-indigo-400 border border-indigo-500/30 rounded-full font-medium">
              Live Interactive Grid
            </span>
          </h2>
          <p className="text-slate-400 text-sm mt-1">{currentLevelInfo?.description}</p>
        </div>

        {/* Level Switcher Buttons */}
        <div className="flex bg-slate-950 p-1.5 rounded-xl border border-slate-800 gap-1">
          {parkingLevels.map(level => {
            const count = spots.filter(s => s.level === level.id && s.status === 'AVAILABLE').length;
            const total = spots.filter(s => s.level === level.id).length;
            const isActive = activeLevel === level.id;

            return (
              <button
                key={level.id}
                onClick={() => { setActiveLevel(level.id); setSelectedSpot(null); }}
                className={`flex items-center gap-2 px-4 py-2 rounded-lg font-medium text-sm transition-all duration-200 ${
                  isActive
                    ? 'bg-indigo-600 text-white shadow-lg shadow-indigo-600/30'
                    : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/60'
                }`}
              >
                <span>{level.id}</span>
                <span className={`text-xs px-2 py-0.5 rounded-md ${
                  isActive ? 'bg-indigo-700/80 text-indigo-100' : 'bg-slate-800 text-slate-400'
                }`}>
                  {count}/{total}
                </span>
              </button>
            );
          })}
        </div>
      </div>

      {/* Spot Filter Toolbar */}
      <div className="flex flex-wrap items-center justify-between gap-4 my-6">
        <div className="flex items-center gap-2 overflow-x-auto pb-2 sm:pb-0">
          <span className="text-xs uppercase tracking-wider font-semibold text-slate-500 mr-2">Filter:</span>
          {[
            { id: 'ALL', label: 'All Slots' },
            { id: 'AVAILABLE', label: 'Available Only' },
            { id: 'OCCUPIED', label: 'Occupied' },
            { id: 'EV', label: 'EV Charging Bay' },
            { id: 'VISITOR', label: 'Visitor Slots' },
          ].map(btn => (
            <button
              key={btn.id}
              onClick={() => setFilterType(btn.id)}
              className={`px-3 py-1.5 rounded-lg text-xs font-medium transition ${
                filterType === btn.id
                  ? 'bg-slate-800 text-indigo-400 border border-indigo-500/40 shadow-sm'
                  : 'bg-slate-950/60 text-slate-400 hover:text-slate-200 border border-slate-800/80'
              }`}
            >
              {btn.label}
            </button>
          ))}
        </div>

        {/* Legend */}
        <div className="flex items-center gap-4 text-xs text-slate-400">
          <span className="flex items-center gap-1.5"><span className="w-3 h-3 rounded bg-emerald-500/20 border border-emerald-500"></span> Available</span>
          <span className="flex items-center gap-1.5"><span className="w-3 h-3 rounded bg-slate-800 border border-slate-600"></span> Occupied</span>
          <span className="flex items-center gap-1.5"><span className="w-3 h-3 rounded bg-cyan-500/20 border border-cyan-400"></span> EV Charger</span>
          <span className="flex items-center gap-1.5"><span className="w-3 h-3 rounded bg-amber-500/20 border border-amber-400"></span> Visitor</span>
        </div>
      </div>

      {/* Grid Floorplan Map */}
      <div className="bg-slate-950 p-6 rounded-2xl border border-slate-800 min-h-[380px] relative overflow-hidden">
        {/* Elevator & Corridor Markers */}
        <div className="flex items-center justify-between mb-6 pb-3 border-b border-dashed border-slate-800/80 text-xs font-mono text-slate-500">
          <span className="flex items-center gap-2 bg-slate-900 px-3 py-1 rounded border border-slate-800 text-indigo-400">
            🏢 Elevator Bank A & B (Towers North/Ocean)
          </span>
          <span className="flex items-center gap-2 bg-slate-900 px-3 py-1 rounded border border-slate-800 text-emerald-400">
            🚧 Main Gate Ramp Corridor
          </span>
          <span className="flex items-center gap-2 bg-slate-900 px-3 py-1 rounded border border-slate-800 text-amber-400">
            🏢 Elevator Bank C (Garden Tower)
          </span>
        </div>

        {/* Parking Spot Grid */}
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6 gap-4">
          {filteredSpots.map(spot => {
            const isOccupied = spot.status === 'OCCUPIED';
            const isEV = spot.type === 'EV' || (spot.evCharging && spot.evCharging.isCharging);
            const isVisitor = spot.type === 'VISITOR';
            const isSelected = selectedSpot?.id === spot.id;

            return (
              <div
                key={spot.id}
                onClick={() => setSelectedSpot(spot)}
                className={`group cursor-pointer relative p-3.5 rounded-xl border transition-all duration-200 transform hover:-translate-y-1 ${
                  isSelected
                    ? 'ring-2 ring-indigo-500 border-indigo-400 bg-indigo-950/40 shadow-lg shadow-indigo-500/20 scale-[1.02]'
                    : isOccupied
                    ? 'bg-slate-900/90 border-slate-800 hover:border-slate-700'
                    : isEV
                    ? 'bg-cyan-950/20 border-cyan-500/40 hover:border-cyan-400 shadow-sm shadow-cyan-500/10'
                    : isVisitor
                    ? 'bg-amber-950/20 border-amber-500/40 hover:border-amber-400 shadow-sm shadow-amber-500/10'
                    : 'bg-emerald-950/20 border-emerald-500/40 hover:border-emerald-400 shadow-sm shadow-emerald-500/10'
                }`}
              >
                {/* Spot Header Info */}
                <div className="flex items-center justify-between text-xs mb-2">
                  <span className="font-mono font-bold text-slate-200 tracking-wider">{spot.id}</span>
                  <div className="flex items-center gap-1">
                    {spot.type === 'EV' && <Zap className="w-3.5 h-3.5 text-cyan-400" />}
                    {spot.type === 'HANDICAP' && <Accessibility className="w-3.5 h-3.5 text-blue-400" />}
                    {spot.type === 'VIP' && <ShieldCheck className="w-3.5 h-3.5 text-amber-400" />}
                    {spot.type === 'VISITOR' && <span className="text-[10px] px-1 bg-amber-500/20 text-amber-300 rounded">GUEST</span>}
                  </div>
                </div>

                {/* Spot Body Status Visual */}
                <div className="h-16 flex flex-col items-center justify-center rounded-lg border border-dashed border-slate-800/80 bg-slate-950/50 p-2 text-center">
                  {isOccupied ? (
                    <div className="flex flex-col items-center w-full">
                      <Car className={`w-7 h-7 mb-1 ${isEV ? 'text-cyan-400' : isVisitor ? 'text-amber-400' : 'text-slate-300'}`} />
                      <span className="text-[11px] font-mono font-bold text-slate-200 truncate w-full">
                        {spot.vehicle?.plate || 'OCCUPIED'}
                      </span>
                    </div>
                  ) : (
                    <div className="flex flex-col items-center text-emerald-400">
                      <span className="text-xs font-semibold">FREE</span>
                      <span className="text-[10px] text-slate-500 mt-0.5">{spot.type}</span>
                    </div>
                  )}
                </div>

                {/* EV Charging Progress Bar (if actively charging) */}
                {spot.evCharging && spot.evCharging.isCharging && (
                  <div className="mt-2.5">
                    <div className="flex justify-between items-center text-[10px] text-cyan-300 mb-1">
                      <span className="flex items-center gap-1"><BatteryCharging className="w-3 h-3 text-cyan-400 animate-pulse" /> {spot.evCharging.kwPower}kW</span>
                      <span className="font-mono">{spot.evCharging.batteryPercent}%</span>
                    </div>
                    <div className="w-full bg-slate-800 h-1.5 rounded-full overflow-hidden">
                      <div
                        className="bg-cyan-400 h-full rounded-full transition-all duration-500"
                        style={{ width: `${spot.evCharging.batteryPercent}%` }}
                      ></div>
                    </div>
                  </div>
                )}
              </div>
            );
          })}
        </div>

        {filteredSpots.length === 0 && (
          <div className="py-16 text-center text-slate-500">
            <AlertCircle className="w-10 h-10 mx-auto mb-2 opacity-50" />
            <p className="text-sm">No parking slots found matching the selected filter on Level {activeLevel}.</p>
          </div>
        )}
      </div>

      {/* Spot Detail Modal */}
      {selectedSpot && (
        <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-slate-800 rounded-2xl w-full max-w-md p-6 shadow-2xl relative animate-in fade-in zoom-in-95 duration-150">
            <button
              onClick={() => setSelectedSpot(null)}
              className="absolute top-4 right-4 p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800"
            >
              <X className="w-5 h-5" />
            </button>

            <div className="flex items-center gap-3 mb-4">
              <div className={`p-3 rounded-xl border ${
                selectedSpot.status === 'OCCUPIED' ? 'bg-indigo-950/50 border-indigo-500/30 text-indigo-400' : 'bg-emerald-950/50 border-emerald-500/30 text-emerald-400'
              }`}>
                <Car className="w-6 h-6" />
              </div>
              <div>
                <h3 className="text-xl font-bold text-white flex items-center gap-2">
                  Slot {selectedSpot.id}
                  <span className={`text-xs px-2 py-0.5 rounded-full border font-semibold ${
                    selectedSpot.status === 'OCCUPIED' ? 'bg-slate-800 text-amber-300 border-amber-500/30' : 'bg-emerald-950 text-emerald-400 border-emerald-500/30'
                  }`}>
                    {selectedSpot.status}
                  </span>
                </h3>
                <p className="text-xs text-slate-400">Level {selectedSpot.level} • {selectedSpot.type} Space</p>
              </div>
            </div>

            {selectedSpot.status === 'OCCUPIED' && selectedSpot.vehicle ? (
              <div className="space-y-4 my-4">
                <div className="bg-slate-950 p-4 rounded-xl border border-slate-800 space-y-2.5 text-sm">
                  <div className="flex justify-between items-center pb-2 border-b border-slate-800">
                    <span className="text-slate-400 flex items-center gap-1.5"><Car className="w-4 h-4 text-indigo-400" /> Plate Number</span>
                    <span className="font-mono font-bold text-amber-400 bg-amber-950/30 px-2 py-0.5 rounded border border-amber-500/30">
                      {selectedSpot.vehicle.plate}
                    </span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-slate-400 flex items-center gap-1.5"><User className="w-4 h-4 text-indigo-400" /> Owner / Resident</span>
                    <span className="text-slate-200 font-medium">{selectedSpot.vehicle.owner}</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-slate-400 flex items-center gap-1.5"><ShieldCheck className="w-4 h-4 text-indigo-400" /> Apartment Unit</span>
                    <span className="text-indigo-300 font-semibold">{selectedSpot.vehicle.unit}</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-slate-400 flex items-center gap-1.5"><Clock className="w-4 h-4 text-indigo-400" /> Access Type</span>
                    <span className="text-slate-300">{selectedSpot.vehicle.type}</span>
                  </div>
                </div>

                {/* EV Charger Controls in Modal */}
                {selectedSpot.evCharging && (
                  <div className="bg-cyan-950/20 border border-cyan-500/30 p-4 rounded-xl space-y-3">
                    <div className="flex items-center justify-between">
                      <span className="text-xs font-semibold text-cyan-300 flex items-center gap-1.5">
                        <Zap className="w-4 h-4 text-cyan-400" /> Smart EV Charger Session
                      </span>
                      <button
                        onClick={() => toggleEVCharging(selectedSpot.id)}
                        className={`text-xs px-2.5 py-1 rounded-lg font-semibold transition ${
                          selectedSpot.evCharging.isCharging
                            ? 'bg-amber-500/20 text-amber-300 border border-amber-500/30 hover:bg-amber-500/30'
                            : 'bg-cyan-500 text-slate-950 hover:bg-cyan-400'
                        }`}
                      >
                        {selectedSpot.evCharging.isCharging ? 'Pause Charging' : 'Start Charging'}
                      </button>
                    </div>

                    <div className="space-y-1">
                      <div className="flex justify-between text-xs text-slate-300 font-mono">
                        <span>Charge State: {selectedSpot.evCharging.isCharging ? 'Charging (22kW)' : 'Idle'}</span>
                        <span>{selectedSpot.evCharging.batteryPercent}%</span>
                      </div>
                      <div className="w-full bg-slate-800 h-2 rounded-full overflow-hidden">
                        <div
                          className="bg-cyan-400 h-full rounded-full transition-all duration-300"
                          style={{ width: `${selectedSpot.evCharging.batteryPercent}%` }}
                        ></div>
                      </div>
                    </div>
                  </div>
                )}

                <button
                  onClick={() => { releaseSpot(selectedSpot.id); setSelectedSpot(null); }}
                  className="w-full py-2.5 bg-rose-500/20 border border-rose-500/30 text-rose-300 font-semibold rounded-xl hover:bg-rose-500/30 transition text-sm flex items-center justify-center gap-2"
                >
                  <Lock className="w-4 h-4" /> Unpark / Checkout Vehicle
                </button>
              </div>
            ) : (
              <div className="space-y-4 my-4">
                <p className="text-xs text-slate-400 bg-slate-950 p-3 rounded-xl border border-slate-800">
                  This space is currently unassigned and ready for parking or resident assignment.
                </p>

                <button
                  onClick={() => setShowAssignModal(true)}
                  className="w-full py-2.5 bg-indigo-600 hover:bg-indigo-500 text-white font-semibold rounded-xl transition text-sm flex items-center justify-center gap-2 shadow-lg shadow-indigo-600/30"
                >
                  <CheckCircle2 className="w-4 h-4" /> Manually Park Vehicle Here
                </button>
              </div>
            )}
          </div>
        </div>
      )}

      {/* Manual Park Assignment Sub-Modal */}
      {showAssignModal && selectedSpot && (
        <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-slate-800 rounded-2xl w-full max-w-sm p-6 shadow-2xl relative">
            <h3 className="text-lg font-bold text-white mb-1">Park Vehicle in {selectedSpot.id}</h3>
            <p className="text-xs text-slate-400 mb-4">Enter vehicle plate and unit details to check-in.</p>

            <form onSubmit={handleManualAssign} className="space-y-3 text-xs">
              <div>
                <label className="block text-slate-300 font-medium mb-1">License Plate Number *</label>
                <input
                  type="text"
                  required
                  placeholder="e.g. ABC-1234"
                  value={manualPlate}
                  onChange={e => setManualPlate(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-lg p-2.5 text-white placeholder-slate-600 focus:outline-none focus:border-indigo-500 uppercase font-mono"
                />
              </div>

              <div>
                <label className="block text-slate-300 font-medium mb-1">Apartment Unit (e.g. A-402)</label>
                <input
                  type="text"
                  placeholder="e.g. Tower B - 1202"
                  value={manualUnit}
                  onChange={e => setManualUnit(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-lg p-2.5 text-white placeholder-slate-600 focus:outline-none focus:border-indigo-500"
                />
              </div>

              <div>
                <label className="block text-slate-300 font-medium mb-1">Driver / Resident Name</label>
                <input
                  type="text"
                  placeholder="e.g. Jane Doe"
                  value={manualOwner}
                  onChange={e => setManualOwner(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-lg p-2.5 text-white placeholder-slate-600 focus:outline-none focus:border-indigo-500"
                />
              </div>

              <div className="flex items-center gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setShowAssignModal(false)}
                  className="w-1/2 py-2 bg-slate-800 text-slate-300 rounded-lg font-semibold hover:bg-slate-700"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="w-1/2 py-2 bg-indigo-600 hover:bg-indigo-500 text-white font-semibold rounded-lg shadow"
                >
                  Confirm Check-in
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
