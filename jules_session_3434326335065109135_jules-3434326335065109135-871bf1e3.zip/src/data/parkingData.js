// Initial mock data for Grand Horizon Apartments Parking System

export const TOWERS = [
  { id: 'A', name: 'Tower A (North Palm)', unitsCount: 40, residentCount: 38 },
  { id: 'B', name: 'Tower B (Ocean View)', unitsCount: 40, residentCount: 40 },
  { id: 'C', name: 'Tower C (Garden Suites)', unitsCount: 40, residentCount: 36 },
];

export const PARKING_LEVELS = [
  {
    id: 'B1',
    name: 'Level B1 - EV & VIP Executive',
    description: 'High-speed EV Fast Chargers, Reserved VIP slots & Priority Access',
    totalSpots: 30,
    evCount: 16,
    handicapCount: 4,
  },
  {
    id: 'B2',
    name: 'Level B2 - Resident Primary',
    description: 'Dedicated resident parking spaces for Towers A, B, and C',
    totalSpots: 40,
    evCount: 6,
    handicapCount: 4,
  },
  {
    id: 'Ground',
    name: 'Ground Level - Visitor & Delivery',
    description: 'Short-term visitor passes, guest charging & drop-off zones',
    totalSpots: 20,
    evCount: 4,
    handicapCount: 4,
  },
  {
    id: 'B3',
    name: 'Level B3 - Resident Secondary & Storage',
    description: 'Extended parking, second vehicles, and resident storage bays',
    totalSpots: 30,
    evCount: 0,
    handicapCount: 2,
  },
];

// Generate comprehensive mock spots
export const INITIAL_SPOTS = [
  // LEVEL B1 (EV & VIP)
  { id: 'B1-01', level: 'B1', type: 'EV', status: 'OCCUPIED', vehicle: { plate: 'EV-882-99', model: 'Tesla Model S', owner: 'Arthur Pendelton', unit: 'A-701', type: 'Resident' }, evCharging: { isCharging: true, batteryPercent: 78, kwPower: 22, startTime: '08:30 AM' } },
  { id: 'B1-02', level: 'B1', type: 'EV', status: 'OCCUPIED', vehicle: { plate: 'EV-104-XX', model: 'Porsche Taycan', owner: 'Elena Rostova', unit: 'B-1202', type: 'Resident' }, evCharging: { isCharging: true, batteryPercent: 94, kwPower: 11, startTime: '09:15 AM' } },
  { id: 'B1-03', level: 'B1', type: 'EV', status: 'AVAILABLE', evCharging: { isCharging: false, batteryPercent: 0, kwPower: 0, startTime: null } },
  { id: 'B1-04', level: 'B1', type: 'EV', status: 'AVAILABLE', evCharging: { isCharging: false, batteryPercent: 0, kwPower: 0, startTime: null } },
  { id: 'B1-05', level: 'B1', type: 'VIP', status: 'OCCUPIED', vehicle: { plate: 'VIP-777', model: 'Mercedes Maybach S680', owner: 'Harrison Forde', unit: 'Penthouse-1', type: 'Resident' } },
  { id: 'B1-06', level: 'B1', type: 'VIP', status: 'AVAILABLE' },
  { id: 'B1-07', level: 'B1', type: 'EV', status: 'OCCUPIED', vehicle: { plate: 'EV-409-KL', model: 'BMW i7', owner: 'Dr. Sophia Martinez', unit: 'C-504', type: 'Resident' }, evCharging: { isCharging: true, batteryPercent: 45, kwPower: 22, startTime: '10:00 AM' } },
  { id: 'B1-08', level: 'B1', type: 'EV', status: 'AVAILABLE', evCharging: { isCharging: false, batteryPercent: 0, kwPower: 0, startTime: null } },
  { id: 'B1-09', level: 'B1', type: 'HANDICAP', status: 'AVAILABLE' },
  { id: 'B1-10', level: 'B1', type: 'HANDICAP', status: 'OCCUPIED', vehicle: { plate: 'ACC-302-H', model: 'Audi e-tron GT', owner: 'George Vance', unit: 'A-102', type: 'Resident' }, evCharging: { isCharging: false, batteryPercent: 100, kwPower: 0, startTime: '07:00 AM' } },
  { id: 'B1-11', level: 'B1', type: 'EV', status: 'AVAILABLE', evCharging: { isCharging: false, batteryPercent: 0, kwPower: 0, startTime: null } },
  { id: 'B1-12', level: 'B1', type: 'EV', status: 'OCCUPIED', vehicle: { plate: 'EV-990-ZZ', model: 'Lucid Air', owner: 'Chloe Bennet', unit: 'B-804', type: 'Resident' }, evCharging: { isCharging: true, batteryPercent: 62, kwPower: 22, startTime: '10:30 AM' } },
  { id: 'B1-13', level: 'B1', type: 'RESIDENT', status: 'OCCUPIED', vehicle: { plate: 'NY-8821-K', model: 'Lexus RX 500h', owner: 'Michael Chang', unit: 'C-301', type: 'Resident' } },
  { id: 'B1-14', level: 'B1', type: 'RESIDENT', status: 'AVAILABLE' },
  { id: 'B1-15', level: 'B1', type: 'RESIDENT', status: 'AVAILABLE' },

  // LEVEL B2 (RESIDENT PRIMARY)
  { id: 'B2-01', level: 'B2', type: 'RESIDENT', status: 'OCCUPIED', vehicle: { plate: 'B2-A101-1', model: 'Honda CR-V', owner: 'David Miller', unit: 'A-101', type: 'Resident' } },
  { id: 'B2-02', level: 'B2', type: 'RESIDENT', status: 'OCCUPIED', vehicle: { plate: 'B2-A102-1', model: 'Toyota Camry', owner: 'Sarah Connor', unit: 'A-102', type: 'Resident' } },
  { id: 'B2-03', level: 'B2', type: 'RESIDENT', status: 'AVAILABLE' },
  { id: 'B2-04', level: 'B2', type: 'RESIDENT', status: 'OCCUPIED', vehicle: { plate: 'B2-B201-1', model: 'Ford F-150 Lightning', owner: 'Jack Reacher', unit: 'B-201', type: 'Resident' }, evCharging: { isCharging: true, batteryPercent: 88, kwPower: 11, startTime: '06:00 AM' } },
  { id: 'B2-05', level: 'B2', type: 'RESIDENT', status: 'AVAILABLE' },
  { id: 'B2-06', level: 'B2', type: 'RESIDENT', status: 'OCCUPIED', vehicle: { plate: 'B2-C303-1', model: 'Mazda CX-5', owner: 'Linda Danvers', unit: 'C-303', type: 'Resident' } },
  { id: 'B2-07', level: 'B2', type: 'RESIDENT', status: 'OCCUPIED', vehicle: { plate: 'B2-A402-1', model: 'Volvo XC90', owner: 'Mark Watney', unit: 'A-402', type: 'Resident' } },
  { id: 'B2-08', level: 'B2', type: 'RESIDENT', status: 'AVAILABLE' },
  { id: 'B2-09', level: 'B2', type: 'RESIDENT', status: 'OCCUPIED', vehicle: { plate: 'B2-B505-1', model: 'Subaru Outback', owner: 'Peter Parker', unit: 'B-505', type: 'Resident' } },
  { id: 'B2-10', level: 'B2', type: 'RESIDENT', status: 'AVAILABLE' },
  { id: 'B2-11', level: 'B2', type: 'RESIDENT', status: 'OCCUPIED', vehicle: { plate: 'B2-C101-1', model: 'Hyundai Ioniq 5', owner: 'Wanda Maximoff', unit: 'C-101', type: 'Resident' }, evCharging: { isCharging: false, batteryPercent: 100, kwPower: 0, startTime: '02:00 AM' } },
  { id: 'B2-12', level: 'B2', type: 'RESIDENT', status: 'AVAILABLE' },

  // GROUND LEVEL (VISITOR)
  { id: 'G-01', level: 'Ground', type: 'VISITOR', status: 'OCCUPIED', vehicle: { plate: 'GUEST-901', model: 'Tesla Model Y', owner: 'Guest of Apt A-402', unit: 'A-402', type: 'Visitor', passExpires: '06:00 PM Today' }, evCharging: { isCharging: true, batteryPercent: 55, kwPower: 7.2, startTime: '11:00 AM' } },
  { id: 'G-02', level: 'Ground', type: 'VISITOR', status: 'AVAILABLE' },
  { id: 'G-03', level: 'Ground', type: 'VISITOR', status: 'AVAILABLE' },
  { id: 'G-04', level: 'Ground', type: 'VISITOR', status: 'OCCUPIED', vehicle: { plate: 'GUEST-312', model: 'Honda Civic', owner: 'Contractor (Plumbing)', unit: 'Management', type: 'Visitor', passExpires: '04:00 PM Today' } },
  { id: 'G-05', level: 'Ground', type: 'VISITOR', status: 'AVAILABLE' },
  { id: 'G-06', level: 'Ground', type: 'HANDICAP', status: 'AVAILABLE' },
  { id: 'G-07', level: 'Ground', type: 'VISITOR', status: 'OCCUPIED', vehicle: { plate: 'DELIVERY-88', model: 'Amazon Rivian Van', owner: 'Courier Service', unit: 'All Towers', type: 'Visitor', passExpires: '01:00 PM Today' } },
  { id: 'G-08', level: 'Ground', type: 'VISITOR', status: 'AVAILABLE' },

  // LEVEL B3 (RESIDENT SECONDARY)
  { id: 'B3-01', level: 'B3', type: 'RESIDENT', status: 'OCCUPIED', vehicle: { plate: 'B3-A701-2', model: 'Chevrolet Corvette', owner: 'Arthur Pendelton', unit: 'A-701', type: 'Resident' } },
  { id: 'B3-02', level: 'B3', type: 'RESIDENT', status: 'AVAILABLE' },
  { id: 'B3-03', level: 'B3', type: 'RESIDENT', status: 'AVAILABLE' },
  { id: 'B3-04', level: 'B3', type: 'RESIDENT', status: 'OCCUPIED', vehicle: { plate: 'B3-B1202-2', model: 'Jeep Wrangler', owner: 'Elena Rostova', unit: 'B-1202', type: 'Resident' } },
  { id: 'B3-05', level: 'B3', type: 'RESIDENT', status: 'AVAILABLE' },
];

export const INITIAL_LOGS = [
  { id: 'LOG-101', timestamp: '11:42 AM', plate: 'EV-882-99', action: 'ENTRY', gate: 'Main North Gate', result: 'APPROVED', unit: 'A-701', spotAssigned: 'B1-01' },
  { id: 'LOG-102', timestamp: '11:30 AM', plate: 'GUEST-901', action: 'ENTRY', gate: 'Visitor Gate', result: 'GUEST PASS VERIFIED', unit: 'A-402', spotAssigned: 'G-01' },
  { id: 'LOG-103', timestamp: '11:15 AM', plate: 'B2-A101-1', action: 'ENTRY', gate: 'Main South Gate', result: 'APPROVED', unit: 'A-101', spotAssigned: 'B2-01' },
  { id: 'LOG-104', timestamp: '10:50 AM', plate: 'UNKNOWN-09', action: 'DENIED', gate: 'Main North Gate', result: 'UNREGISTERED PLATE', unit: 'N/A', spotAssigned: '-' },
  { id: 'LOG-105', timestamp: '10:12 AM', plate: 'VIP-777', action: 'ENTRY', gate: 'VIP Express Gate', result: 'APPROVED', unit: 'Penthouse-1', spotAssigned: 'B1-05' },
];

export const REGISTERED_RESIDENTS = [
  { name: 'Arthur Pendelton', unit: 'A-701', tower: 'Tower A', primaryPlate: 'EV-882-99', primarySpot: 'B1-01', secondaryPlate: 'B3-A701-2', secondarySpot: 'B3-01' },
  { name: 'Elena Rostova', unit: 'B-1202', tower: 'Tower B', primaryPlate: 'EV-104-XX', primarySpot: 'B1-02', secondaryPlate: 'B3-B1202-2', secondarySpot: 'B3-04' },
  { name: 'Mark Watney', unit: 'A-402', tower: 'Tower A', primaryPlate: 'B2-A402-1', primarySpot: 'B2-07', secondaryPlate: null, secondarySpot: null },
  { name: 'Harrison Forde', unit: 'Penthouse-1', tower: 'Tower A', primaryPlate: 'VIP-777', primarySpot: 'B1-05', secondaryPlate: null, secondarySpot: null },
  { name: 'David Miller', unit: 'A-101', tower: 'Tower A', primaryPlate: 'B2-A101-1', primarySpot: 'B2-01', secondaryPlate: null, secondarySpot: null },
  { name: 'Dr. Sophia Martinez', unit: 'C-504', tower: 'Tower C', primaryPlate: 'EV-409-KL', primarySpot: 'B1-07', secondaryPlate: null, secondarySpot: null },
  { name: 'Jack Reacher', unit: 'B-201', tower: 'Tower B', primaryPlate: 'B2-B201-1', primarySpot: 'B2-04', secondaryPlate: null, secondarySpot: null },
];
