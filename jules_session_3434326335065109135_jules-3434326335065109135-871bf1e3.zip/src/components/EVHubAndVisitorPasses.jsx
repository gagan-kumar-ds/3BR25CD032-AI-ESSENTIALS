import React, { useState } from 'react';
import { useParking } from '../context/ParkingContext';
import { Zap, BatteryCharging, Power, Plus, Ticket, Users, Check, AlertTriangle, ShieldCheck } from 'lucide-react';

export default function EVHubAndVisitorPasses() {
  const { spots, toggleEVCharging, residents, issueVisitorPass } = useParking();
  const [activeTab, setActiveTab] = useState('EV_HUB');

  // Visitor Pass form state
  const [guestName, setGuestName] = useState('');
  const [guestPlate, setGuestPlate] = useState('');
  const [hostUnit, setHostUnit] = useState('A-701');
  const [passSuccessMsg, setPassSuccessMsg] = useState('');

  const evSpots = spots.filter(s => s.type === 'EV' || (s.evCharging && s.evCharging.isCharging));
  const activeChargersCount = evSpots.filter(s => s.evCharging && s.evCharging.isCharging).length;
  const totalPowerKW = evSpots.reduce((acc, s) => acc + (s.evCharging?.isCharging ? s.evCharging.kwPower : 0), 0);

  const handleIssuePass = (e) => {
    e.preventDefault();
    if (!guestName || !guestPlate) return;

    issueVisitorPass(guestName, guestPlate, hostUnit);
    setPassSuccessMsg(`Digital Guest Pass created for ${guestName} (${guestPlate.toUpperCase()})! Valid on Ground Visitor Level.`);
    setGuestName('');
    setGuestPlate('');

    setTimeout(() => {
      setPassSuccessMsg('');
    }, 5000);
  };

  return (
    <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-6 shadow-xl backdrop-blur-md">
      {/* Top Section Tabs */}
      <div className="flex flex-wrap items-center justify-between gap-4 pb-6 border-b border-slate-800">
        <div>
          <h2 className="text-2xl font-bold text-white flex items-center gap-2">
            {activeTab === 'EV_HUB' ? <Zap className="w-6 h-6 text-cyan-400" /> : <Ticket className="w-6 h-6 text-amber-400" />}
            <span>{activeTab === 'EV_HUB' ? 'Smart EV Fast-Charging Hub' : 'Resident Guest & Visitor Pass Management'}</span>
          </h2>
          <p className="text-slate-400 text-xs mt-1">
            {activeTab === 'EV_HUB'
              ? 'Real-time telemetry, wattage monitoring, and charging control across all parking levels'
              : 'Issue digital guest passes and view resident vehicle registrations for Towers A, B, and C'}
          </p>
        </div>

        <div className="flex bg-slate-950 p-1.5 rounded-xl border border-slate-800 gap-1">
          <button
            onClick={() => setActiveTab('EV_HUB')}
            className={`px-4 py-2 rounded-lg font-medium text-xs transition-all flex items-center gap-1.5 ${
              activeTab === 'EV_HUB'
                ? 'bg-cyan-600 text-white shadow-lg shadow-cyan-600/30'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <Zap className="w-3.5 h-3.5" />
            <span>EV Charging Network</span>
          </button>
          <button
            onClick={() => setActiveTab('VISITOR_PASSES')}
            className={`px-4 py-2 rounded-lg font-medium text-xs transition-all flex items-center gap-1.5 ${
              activeTab === 'VISITOR_PASSES'
                ? 'bg-amber-600 text-white shadow-lg shadow-amber-600/30'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <Ticket className="w-3.5 h-3.5" />
            <span>Visitor Guest Passes</span>
          </button>
        </div>
      </div>

      {activeTab === 'EV_HUB' ? (
        <div className="space-y-6 my-6">
          {/* Telemetry Summary Cards */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div className="bg-slate-950 p-4 rounded-xl border border-slate-800 flex items-center gap-3">
              <div className="p-3 bg-cyan-500/20 text-cyan-400 rounded-xl border border-cyan-500/30">
                <Zap className="w-6 h-6" />
              </div>
              <div>
                <span className="text-slate-400 text-xs font-semibold uppercase tracking-wider block">Total Power Output</span>
                <span className="text-xl font-mono font-bold text-cyan-300">{totalPowerKW} kW</span>
              </div>
            </div>

            <div className="bg-slate-950 p-4 rounded-xl border border-slate-800 flex items-center gap-3">
              <div className="p-3 bg-indigo-500/20 text-indigo-400 rounded-xl border border-indigo-500/30">
                <BatteryCharging className="w-6 h-6" />
              </div>
              <div>
                <span className="text-slate-400 text-xs font-semibold uppercase tracking-wider block">Active Sessions</span>
                <span className="text-xl font-mono font-bold text-white">{activeChargersCount} / {evSpots.length} Bays</span>
              </div>
            </div>

            <div className="bg-slate-950 p-4 rounded-xl border border-slate-800 flex items-center gap-3">
              <div className="p-3 bg-emerald-500/20 text-emerald-400 rounded-xl border border-emerald-500/30">
                <Power className="w-6 h-6" />
              </div>
              <div>
                <span className="text-slate-400 text-xs font-semibold uppercase tracking-wider block">Network Health</span>
                <span className="text-xl font-bold text-emerald-400">100% Online</span>
              </div>
            </div>
          </div>

          {/* EV Charging Stations Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {evSpots.map((spot) => {
              const isCharging = spot.evCharging && spot.evCharging.isCharging;
              const battery = spot.evCharging ? spot.evCharging.batteryPercent : 0;

              return (
                <div
                  key={spot.id}
                  className={`bg-slate-950 p-4 rounded-xl border transition-all ${
                    isCharging ? 'border-cyan-500/40 shadow-md shadow-cyan-500/10' : 'border-slate-800/80 opacity-85'
                  }`}
                >
                  <div className="flex items-center justify-between pb-2 border-b border-slate-800">
                    <div>
                      <span className="font-mono font-bold text-sm text-white">{spot.id}</span>
                      <span className="text-[10px] text-slate-400 block">Level {spot.level}</span>
                    </div>

                    <button
                      onClick={() => toggleEVCharging(spot.id)}
                      className={`px-3 py-1 rounded-lg text-xs font-bold transition flex items-center gap-1.5 ${
                        isCharging
                          ? 'bg-amber-500/20 text-amber-300 border border-amber-500/30 hover:bg-amber-500/30'
                          : 'bg-cyan-500 text-slate-950 hover:bg-cyan-400'
                      }`}
                    >
                      <Power className="w-3 h-3" />
                      {isCharging ? 'Pause' : 'Start Charge'}
                    </button>
                  </div>

                  {spot.vehicle ? (
                    <div className="mt-3 space-y-2 text-xs">
                      <div className="flex justify-between items-center text-slate-300">
                        <span className="font-mono font-bold text-amber-300 bg-amber-950/40 px-2 py-0.5 rounded border border-amber-500/20">
                          {spot.vehicle.plate}
                        </span>
                        <span className="text-indigo-300 font-medium">Unit {spot.vehicle.unit}</span>
                      </div>

                      <div className="space-y-1 pt-1">
                        <div className="flex justify-between text-[11px] text-slate-400 font-mono">
                          <span>Battery Level</span>
                          <span className="text-cyan-300 font-bold">{battery}%</span>
                        </div>
                        <div className="w-full bg-slate-800 h-2 rounded-full overflow-hidden">
                          <div
                            className={`h-full rounded-full transition-all duration-300 ${isCharging ? 'bg-cyan-400 animate-pulse' : 'bg-slate-600'}`}
                            style={{ width: `${battery}%` }}
                          ></div>
                        </div>
                      </div>
                    </div>
                  ) : (
                    <div className="mt-4 py-3 text-center text-xs text-slate-500 font-medium bg-slate-900/50 rounded-lg border border-dashed border-slate-800">
                      EV Slot Unoccupied
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        </div>
      ) : (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 my-6">
          {/* Form to issue Guest Pass */}
          <div className="lg:col-span-5 space-y-4">
            <div className="bg-slate-950 p-5 rounded-2xl border border-slate-800 space-y-4">
              <h3 className="text-sm font-bold text-white flex items-center gap-2">
                <Plus className="w-4 h-4 text-amber-400" />
                <span>Issue Digital Guest Pass</span>
              </h3>

              {passSuccessMsg && (
                <div className="p-3 bg-emerald-950/40 border border-emerald-500/40 rounded-xl text-emerald-300 text-xs flex items-center gap-2">
                  <Check className="w-4 h-4 flex-shrink-0" />
                  <span>{passSuccessMsg}</span>
                </div>
              )}

              <form onSubmit={handleIssuePass} className="space-y-3 text-xs">
                <div>
                  <label className="block text-slate-400 font-medium mb-1">Guest / Visitor Name *</label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. Samuel Jackson"
                    value={guestName}
                    onChange={(e) => setGuestName(e.target.value)}
                    className="w-full bg-slate-900 border border-slate-700 rounded-xl p-2.5 text-white focus:outline-none focus:border-amber-500"
                  />
                </div>

                <div>
                  <label className="block text-slate-400 font-medium mb-1">Visitor License Plate *</label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. GUEST-88"
                    value={guestPlate}
                    onChange={(e) => setGuestPlate(e.target.value)}
                    className="w-full bg-slate-900 border border-slate-700 rounded-xl p-2.5 text-amber-300 font-mono font-bold uppercase focus:outline-none focus:border-amber-500"
                  />
                </div>

                <div>
                  <label className="block text-slate-400 font-medium mb-1">Host Apartment Unit</label>
                  <select
                    value={hostUnit}
                    onChange={(e) => setHostUnit(e.target.value)}
                    className="w-full bg-slate-900 border border-slate-700 rounded-xl p-2.5 text-white focus:outline-none focus:border-amber-500"
                  >
                    <option value="A-701">Tower A - Apt 701 (Arthur Pendelton)</option>
                    <option value="B-1202">Tower B - Apt 1202 (Elena Rostova)</option>
                    <option value="A-402">Tower A - Apt 402 (Mark Watney)</option>
                    <option value="C-504">Tower C - Apt 504 (Dr. Sophia Martinez)</option>
                  </select>
                </div>

                <button
                  type="submit"
                  className="w-full py-3 bg-amber-600 hover:bg-amber-500 text-slate-950 font-bold rounded-xl shadow-lg shadow-amber-600/20 transition text-sm flex items-center justify-center gap-2 mt-2"
                >
                  <Ticket className="w-4 h-4" />
                  <span>Generate Visitor Pass</span>
                </button>
              </form>
            </div>
          </div>

          {/* Registered Residents & Guest Passes Directory */}
          <div className="lg:col-span-7 bg-slate-950 p-5 rounded-2xl border border-slate-800">
            <h3 className="text-xs font-bold uppercase tracking-wider text-slate-400 mb-4 flex items-center justify-between">
              <span className="flex items-center gap-1.5"><Users className="w-4 h-4 text-indigo-400" /> Active Registered Resident Directory</span>
              <span className="text-[10px] text-slate-500">{residents.length} Total Registered</span>
            </h3>

            <div className="space-y-3 max-h-[380px] overflow-y-auto pr-1">
              {residents.map((res, idx) => (
                <div key={idx} className="p-3 rounded-xl bg-slate-900 border border-slate-800 flex items-center justify-between text-xs">
                  <div>
                    <h4 className="font-bold text-white flex items-center gap-2">
                      {res.name}
                      <span className="text-[10px] px-2 py-0.5 bg-indigo-500/20 text-indigo-300 rounded border border-indigo-500/30">
                        {res.unit} ({res.tower})
                      </span>
                    </h4>
                    <div className="flex items-center gap-3 mt-1.5 font-mono text-[11px]">
                      <span className="text-amber-300">Plate 1: {res.primaryPlate}</span>
                      {res.secondaryPlate && <span className="text-slate-400">Plate 2: {res.secondaryPlate}</span>}
                    </div>
                  </div>

                  <div className="text-right">
                    <span className="text-[10px] text-slate-500 block">Assigned Spot</span>
                    <span className="font-mono font-bold text-emerald-400">{res.primarySpot}</span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
