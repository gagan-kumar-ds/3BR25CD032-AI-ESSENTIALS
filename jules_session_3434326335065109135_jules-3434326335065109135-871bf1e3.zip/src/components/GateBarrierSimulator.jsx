import React, { useState } from 'react';
import { useParking } from '../context/ParkingContext';
import { Camera, Shield, CheckCircle, XCircle, ArrowRight, Activity, Car, FileText, Sparkles } from 'lucide-react';

export default function GateBarrierSimulator() {
  const { processANPREntry, logs, residents } = useParking();
  const [inputPlate, setInputPlate] = useState('EV-882-99');
  const [isVisitor, setIsVisitor] = useState(false);
  const [hostUnit, setHostUnit] = useState('A-402');
  const [scanResult, setScanResult] = useState(null);
  const [isBarrierOpen, setIsBarrierOpen] = useState(false);
  const [isScanning, setIsScanning] = useState(false);

  const handleSimulateScan = (e) => {
    e.preventDefault();
    if (!inputPlate) return;

    setIsScanning(true);
    setScanResult(null);

    setTimeout(() => {
      const res = processANPREntry(inputPlate, isVisitor, hostUnit);
      setScanResult(res);
      setIsScanning(false);

      if (res.success) {
        setIsBarrierOpen(true);
        setTimeout(() => {
          setIsBarrierOpen(false);
        }, 4000);
      } else {
        setIsBarrierOpen(false);
      }
    }, 800);
  };

  const setQuickPlate = (plate, visitor = false, unit = '') => {
    setInputPlate(plate);
    setIsVisitor(visitor);
    if (unit) setHostUnit(unit);
  };

  return (
    <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-6 shadow-xl backdrop-blur-md">
      <div className="flex items-center justify-between pb-4 border-b border-slate-800 mb-6">
        <div>
          <h2 className="text-2xl font-bold text-white flex items-center gap-2">
            <Camera className="w-6 h-6 text-indigo-400" />
            <span>ANPR Smart Gate Barrier Terminal</span>
          </h2>
          <p className="text-slate-400 text-xs mt-1">Automatic Number Plate Recognition & Automated Parking Gate Control</p>
        </div>

        <div className="flex items-center gap-2 text-xs font-mono">
          <span className="w-2.5 h-2.5 rounded-full bg-emerald-500 animate-ping"></span>
          <span className="text-emerald-400 font-semibold">Camera Feeds Active</span>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Terminal Input Controls */}
        <div className="lg:col-span-5 space-y-4">
          <div className="bg-slate-950 p-5 rounded-2xl border border-slate-800 space-y-4">
            <h3 className="text-sm font-semibold text-slate-200 flex items-center justify-between">
              <span>Vehicle Arrival Simulation</span>
              <Sparkles className="w-4 h-4 text-indigo-400" />
            </h3>

            <form onSubmit={handleSimulateScan} className="space-y-3 text-xs">
              <div>
                <label className="block text-slate-400 font-medium mb-1">License Plate Number</label>
                <div className="relative">
                  <input
                    type="text"
                    required
                    placeholder="Enter License Plate"
                    value={inputPlate}
                    onChange={(e) => setInputPlate(e.target.value.toUpperCase())}
                    className="w-full bg-slate-900 border border-slate-700 rounded-xl p-3 text-amber-400 font-mono font-bold text-base tracking-widest uppercase focus:outline-none focus:border-indigo-500 shadow-inner"
                  />
                  <Car className="w-5 h-5 text-slate-500 absolute right-3 top-3" />
                </div>
              </div>

              <div className="flex items-center gap-3 py-1">
                <label className="flex items-center gap-2 cursor-pointer text-slate-300 font-medium">
                  <input
                    type="checkbox"
                    checked={isVisitor}
                    onChange={(e) => setIsVisitor(e.target.checked)}
                    className="w-4 h-4 rounded border-slate-700 bg-slate-900 text-indigo-600 focus:ring-indigo-500"
                  />
                  <span>Visitor Guest Access Pass</span>
                </label>
              </div>

              {isVisitor && (
                <div>
                  <label className="block text-slate-400 font-medium mb-1">Host Apartment Unit Number</label>
                  <input
                    type="text"
                    placeholder="e.g. A-402 or B-1202"
                    value={hostUnit}
                    onChange={(e) => setHostUnit(e.target.value)}
                    className="w-full bg-slate-900 border border-slate-700 rounded-xl p-2.5 text-white focus:outline-none focus:border-indigo-500"
                  />
                </div>
              )}

              <button
                type="submit"
                disabled={isScanning}
                className="w-full py-3 bg-indigo-600 hover:bg-indigo-500 disabled:opacity-50 text-white font-bold rounded-xl shadow-lg shadow-indigo-600/30 transition flex items-center justify-center gap-2 text-sm mt-2"
              >
                {isScanning ? (
                  <Activity className="w-5 h-5 animate-spin" />
                ) : (
                  <>
                    <span>Trigger Gate Plate Scan</span>
                    <ArrowRight className="w-4 h-4" />
                  </>
                )}
              </button>
            </form>

            {/* Quick Test Presets */}
            <div className="pt-3 border-t border-slate-800/80">
              <span className="text-[11px] font-semibold text-slate-500 uppercase tracking-wider block mb-2">Test Presets:</span>
              <div className="flex flex-wrap gap-2 text-[11px]">
                <button
                  type="button"
                  onClick={() => setQuickPlate('EV-882-99', false)}
                  className="px-2.5 py-1 bg-slate-900 hover:bg-slate-800 border border-slate-800 text-indigo-300 rounded-lg font-mono"
                >
                  EV-882-99 (Res A-701)
                </button>
                <button
                  type="button"
                  onClick={() => setQuickPlate('VIP-777', false)}
                  className="px-2.5 py-1 bg-slate-900 hover:bg-slate-800 border border-slate-800 text-amber-300 rounded-lg font-mono"
                >
                  VIP-777 (Penthouse)
                </button>
                <button
                  type="button"
                  onClick={() => setQuickPlate('GUEST-990', true, 'B-1202')}
                  className="px-2.5 py-1 bg-slate-900 hover:bg-slate-800 border border-slate-800 text-emerald-300 rounded-lg font-mono"
                >
                  GUEST Pass (B-1202)
                </button>
                <button
                  type="button"
                  onClick={() => setQuickPlate('UNREG-99', false)}
                  className="px-2.5 py-1 bg-slate-900 hover:bg-slate-800 border border-slate-800 text-rose-400 rounded-lg font-mono"
                >
                  UNREG-99 (Unregistered)
                </button>
              </div>
            </div>
          </div>
        </div>

        {/* Live Gate Visualizer & Result */}
        <div className="lg:col-span-7 flex flex-col justify-between space-y-4">
          <div className="bg-slate-950 p-5 rounded-2xl border border-slate-800 relative overflow-hidden flex-1 flex flex-col justify-between">
            {/* Visual Gate Indicator */}
            <div>
              <div className="flex items-center justify-between mb-4">
                <span className="text-xs uppercase font-semibold tracking-wider text-slate-400 flex items-center gap-2">
                  <Shield className="w-4 h-4 text-indigo-400" /> Main Gate Barrier Status
                </span>
                <span className={`px-3 py-1 rounded-full text-xs font-bold border transition-all duration-300 ${
                  isBarrierOpen
                    ? 'bg-emerald-500/20 text-emerald-400 border-emerald-500/40 animate-pulse'
                    : 'bg-rose-500/20 text-rose-400 border-rose-500/40'
                }`}>
                  {isBarrierOpen ? 'BARRIER LIFTED [OPEN]' : 'BARRIER DOWN [CLOSED]'}
                </span>
              </div>

              {/* Graphic Representation of Gate */}
              <div className="relative h-28 bg-slate-900/80 rounded-xl border border-slate-800 flex items-center justify-center overflow-hidden">
                <div className="absolute left-6 bottom-0 top-0 w-4 bg-slate-700 rounded-t border-r border-slate-600"></div>

                {/* Barrier Arm */}
                <div
                  className={`absolute left-8 h-3 bg-gradient-to-r from-amber-500 via-rose-500 to-amber-500 rounded-r shadow-lg transition-all duration-700 transform origin-left ${
                    isBarrierOpen ? '-rotate-45 -translate-y-6 w-56' : 'rotate-0 w-64'
                  }`}
                ></div>

                {/* Scanning Laser FX */}
                {isScanning && (
                  <div className="absolute inset-x-0 h-1 bg-indigo-500 shadow-lg shadow-indigo-500/80 animate-pulse top-1/2"></div>
                )}

                <div className="z-10 text-center">
                  <span className="text-2xl font-mono font-extrabold text-amber-300 tracking-widest bg-slate-950/80 px-4 py-1.5 rounded-lg border border-slate-700 shadow">
                    {inputPlate || 'NO PLATE'}
                  </span>
                </div>
              </div>
            </div>

            {/* Scan Output Result Display */}
            <div className="mt-4">
              {scanResult ? (
                <div className={`p-4 rounded-xl border flex items-start gap-3 transition-all ${
                  scanResult.success
                    ? 'bg-emerald-950/30 border-emerald-500/40 text-emerald-300'
                    : 'bg-rose-950/30 border-rose-500/40 text-rose-300'
                }`}>
                  {scanResult.success ? (
                    <CheckCircle className="w-6 h-6 text-emerald-400 flex-shrink-0 mt-0.5" />
                  ) : (
                    <XCircle className="w-6 h-6 text-rose-400 flex-shrink-0 mt-0.5" />
                  )}
                  <div>
                    <h4 className="font-bold text-sm">{scanResult.success ? 'Access Authorized' : 'Access Denied'}</h4>
                    <p className="text-xs mt-0.5 opacity-90">{scanResult.message}</p>
                  </div>
                </div>
              ) : (
                <div className="p-4 rounded-xl bg-slate-900/60 border border-slate-800 text-xs text-slate-500 text-center">
                  Ready to scan approaching vehicle at ANPR Camera Terminal...
                </div>
              )}
            </div>
          </div>

          {/* Live Gate Access Activity Stream */}
          <div className="bg-slate-950 p-4 rounded-2xl border border-slate-800">
            <h3 className="text-xs font-bold uppercase tracking-wider text-slate-400 mb-3 flex items-center justify-between">
              <span className="flex items-center gap-1.5"><FileText className="w-4 h-4 text-indigo-400" /> Recent Gate Passage Logs</span>
              <span className="text-[10px] text-slate-500 font-normal">Auto-Updated</span>
            </h3>

            <div className="space-y-2 max-h-32 overflow-y-auto pr-1">
              {logs.slice(0, 4).map((log) => (
                <div key={log.id} className="flex items-center justify-between text-xs p-2 rounded-lg bg-slate-900 border border-slate-800/80">
                  <div className="flex items-center gap-2">
                    <span className="font-mono text-slate-500 text-[10px]">{log.timestamp}</span>
                    <span className="font-mono font-bold text-amber-300 px-1.5 py-0.5 bg-amber-950/40 rounded border border-amber-500/20">{log.plate}</span>
                    <span className="text-slate-400 text-[11px]">{log.unit !== 'N/A' ? `Unit ${log.unit}` : ''}</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <span className="text-slate-400 text-[11px]">Spot: {log.spotAssigned}</span>
                    <span className={`px-2 py-0.5 rounded text-[10px] font-semibold ${
                      log.action === 'ENTRY' ? 'bg-emerald-500/20 text-emerald-400' : 'bg-rose-500/20 text-rose-400'
                    }`}>
                      {log.action}
                    </span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
